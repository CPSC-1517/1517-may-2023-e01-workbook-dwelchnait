﻿namespace WebApp.Models
{
    public class Assessment
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
