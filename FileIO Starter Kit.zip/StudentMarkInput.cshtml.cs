using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.IO;
using System.Reflection;
using WebApp.Models;

namespace WebApp.Pages.Samples
{
    public class StudentMarkInputModel : PageModel
    {
        public string Feedback { get; set; }
        public bool HasFeedback { get { return !string.IsNullOrWhiteSpace(Feedback); } }
        public IWebHostEnvironment _webHostEnvironment { get; set; }

      
        public StudentMarks studentRecord { get; set; }
      
        [BindProperty]
        public string? FirstName { get; set; }
        [BindProperty]
        public string? LastName { get; set; }

        [BindProperty]
        public int Assessment { get; set; }

        [BindProperty]
        public int AssessmentVersion { get; set; }

        [BindProperty]
        public double Mark { get; set; }

        public StudentMarkInputModel(IWebHostEnvironment env)
        {
            _webHostEnvironment = env;
        }
        public void OnGet()
        {
           
        }
      

        public IActionResult OnPostRecord()
        {
           
           
            return Page();
        }
        public IActionResult OnPostClear()
        {
           
            
            return Page();
        }
        public IActionResult OnPostRedirectToReport()
        {

            return RedirectToPage("StudentMarkReport");
        }
    }
}
